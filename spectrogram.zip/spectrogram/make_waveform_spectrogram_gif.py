import argparse
import os
from pathlib import Path
import random

import numpy as np
import matplotlib.pyplot as plt
import imageio

# Import your spectrogram helpers
def load_spec_core(path: str):
    import importlib.util
    spec = importlib.util.spec_from_file_location("spectrogram_core", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_waveform(npy_path: Path) -> np.ndarray:
    """
    Robust-ish loader:
    - handles plain 1D arrays
    - handles arrays with extra dims by squeezing
    - handles saved dict/object arrays (common in research code)
    """
    x = np.load(npy_path, allow_pickle=True)

    # If it's an object array containing a dict
    if isinstance(x, np.ndarray) and x.dtype == object and x.size == 1:
        x0 = x.item()
        if isinstance(x0, dict):
            # Try common keys; adjust if your cache uses different naming
            for k in ["waveform", "signal", "x", "data"]:
                if k in x0:
                    x = x0[k]
                    break
            else:
                raise ValueError(f"{npy_path} looks like dict but no known waveform key found. Keys={list(x0.keys())}")
        else:
            x = x0

    x = np.asarray(x)

    # Squeeze and enforce 1D
    x = np.squeeze(x)

    if x.ndim == 2:
        # Common pattern: (channels, samples) or (samples, channels)
        # We'll take the longest axis as "samples" and pick channel 0.
        if x.shape[0] < x.shape[1]:
            x = x[0, :]
        else:
            x = x[:, 0]
        x = np.squeeze(x)

    if x.ndim != 1:
        raise ValueError(f"{npy_path} waveform ended up with shape {x.shape}, expected 1D-ish.")

    # Convert to float for scipy/matplotlib friendliness
    return x.astype(np.float32, copy=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--folder", required=True, help="Folder containing .npy waveforms (recurses).")
    ap.add_argument("--out", default="spectrogram_samples.gif", help="Output file (.gif or .mp4).")
    ap.add_argument("--n", type=int, default=50, help="How many random waveforms to sample.")
    ap.add_argument("--seed", type=int, default=0, help="RNG seed for repeatable sampling.")

    # Spectrogram params (set defaults that you can override)
    ap.add_argument("--fs", type=float, default=400_000.0, help="Sample rate (Hz).")
    ap.add_argument("--win", type=int, default=256, help="nperseg / window length (samples).")
    ap.add_argument("--noverlap", type=int, default=192, help="noverlap (samples).")
    ap.add_argument("--nfft", type=int, default=1024, help="NFFT.")
    ap.add_argument("--fmin", type=float, default=0.0, help="Min freq to display (Hz).")
    ap.add_argument("--fmax", type=float, default=200_000.0, help="Max freq to display (Hz).")
    ap.add_argument("--dbrange", type=float, default=80.0, help="Clip range in dB (e.g., 60–120).")

    # Visual/output params
    ap.add_argument("--fps", type=int, default=10, help="Frames/sec for gif/mp4.")
    ap.add_argument("--bare", action="store_true", help="Bare-bones plot (no axes/colorbar). Faster/cleaner.")
    ap.add_argument("--dpi", type=int, default=120, help="Render DPI.")

    ap.add_argument("--spec_core", default="spectrogram_core.py", help="Path to your spectrogram_core.py")

    args = ap.parse_args()

    folder = Path(args.folder)
    if not folder.exists():
        raise FileNotFoundError(f"Folder not found: {folder}")

    spec_core = load_spec_core(args.spec_core)

    # Collect .npy files
    npy_files = sorted(folder.rglob("*.npy"))
    if not npy_files:
        raise RuntimeError(f"No .npy files found under: {folder}")

    rng = random.Random(args.seed)
    chosen = rng.sample(npy_files, k=min(args.n, len(npy_files)))

    frames = []
    out_path = Path(args.out)

    for i, p in enumerate(chosen, start=1):
        x = load_waveform(p)

        # Your helper does: scipy.signal.spectrogram + optional f-clip + optional dB clip :contentReference[oaicite:2]{index=2}
        s, f, t = spec_core.get_cleaned_spectrogram(
            signal=x,
            Fs=args.fs,
            window_length=args.win,
            noverlap=args.noverlap,
            NFFT=args.nfft,
            T0=0,
            clipF=True,
            f_bounds=[args.fmin, args.fmax],
            clipS=True,
            dB_range=args.dbrange,
        )

        # Render to an RGB image in-memory
        fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=args.dpi)

        title = None if args.bare else f"{i}/{len(chosen)}  {p.name}"
        # Your plotter uses pcolormesh(t*1000, f/1000, s) and can hide axes if bare_bones :contentReference[oaicite:3]{index=3}
        spec_core.plot_spectrogram(
            s=s,
            f=f,
            t=t,
            fig=fig,
            ax=ax,
            bulk=False,
            bare_bones=args.bare,
            title=title,
            show_plots=False,
            save_plots=False,
        )

        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        img = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape(h, w, 3)
        frames.append(img)
        plt.close(fig)

        if i % 10 == 0:
            print(f"Rendered {i}/{len(chosen)} frames...")

    # Write output
    ext = out_path.suffix.lower()
    if ext == ".gif":
        imageio.mimsave(out_path, frames, fps=args.fps)
    elif ext == ".mp4":
        # requires imageio[ffmpeg]
        imageio.mimsave(out_path, frames, fps=args.fps, codec="libx264", quality=8)
    else:
        raise ValueError("Output must end with .gif or .mp4")

    print(f"Saved: {out_path.resolve()}")


if __name__ == "__main__":
    main()